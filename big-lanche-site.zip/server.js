const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database("big_lanche.db");
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "troque-esta-senha";

db.exec(`
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 price REAL NOT NULL,
 category TEXT DEFAULT 'Lanches',
 active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer TEXT NOT NULL,
 phone TEXT NOT NULL,
 address TEXT,
 items TEXT NOT NULL,
 total REAL NOT NULL,
 status TEXT DEFAULT 'Novo',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

if (db.prepare("SELECT COUNT(*) c FROM products").get().c === 0) {
  const ins = db.prepare("INSERT INTO products (name,price,category) VALUES (?,?,?)");
  [["X-Burger",18,"Hambúrgueres"],["X-Salada",22,"Hambúrgueres"],["Batata P",10,"Porções"],["Refrigerante",6,"Bebidas"]].forEach(x=>ins.run(...x));
}

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || "big-lanche-session-change-me",
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure: process.env.NODE_ENV==="production"}
}));
app.use(express.static(path.join(__dirname,"public")));

function admin(req,res,next){
  if(req.session.admin) return next();
  res.status(401).json({error:"Não autorizado"});
}

app.get("/api/products",(req,res)=>{
  res.json(db.prepare("SELECT * FROM products WHERE active=1 ORDER BY category,name").all());
});

app.post("/api/orders",(req,res)=>{
  const {customer,phone,address,items,total}=req.body;
  if(!customer || !phone || !Array.isArray(items) || !items.length) return res.status(400).json({error:"Preencha os dados do pedido."});
  const result=db.prepare("INSERT INTO orders(customer,phone,address,items,total) VALUES (?,?,?,?,?)")
    .run(customer,phone,address||"",JSON.stringify(items),Number(total)||0);
  res.json({ok:true,id:result.lastInsertRowid});
});

app.post("/api/admin/login",(req,res)=>{
  if(req.body.password===ADMIN_PASSWORD){req.session.admin=true; return res.json({ok:true});}
  res.status(401).json({error:"Senha incorreta"});
});
app.post("/api/admin/logout",(req,res)=>{req.session.destroy(()=>res.json({ok:true}));});
app.get("/api/admin/me",(req,res)=>res.json({admin:!!req.session.admin}));

app.get("/api/admin/products",admin,(req,res)=>res.json(db.prepare("SELECT * FROM products ORDER BY category,name").all()));
app.post("/api/admin/products",admin,(req,res)=>{
  const {name,price,category}=req.body;
  if(!name || isNaN(Number(price))) return res.status(400).json({error:"Dados inválidos"});
  const r=db.prepare("INSERT INTO products(name,price,category) VALUES (?,?,?)").run(name,Number(price),category||"Lanches");
  res.json({id:r.lastInsertRowid});
});
app.put("/api/admin/products/:id",admin,(req,res)=>{
  const {name,price,category,active}=req.body;
  db.prepare("UPDATE products SET name=?,price=?,category=?,active=? WHERE id=?")
    .run(name,Number(price),category||"Lanches",active?1:0,req.params.id);
  res.json({ok:true});
});
app.delete("/api/admin/products/:id",admin,(req,res)=>{
  db.prepare("UPDATE products SET active=0 WHERE id=?").run(req.params.id);
  res.json({ok:true});
});
app.get("/api/admin/orders",admin,(req,res)=>{
  const rows=db.prepare("SELECT * FROM orders ORDER BY id DESC").all();
  rows.forEach(r=>r.items=JSON.parse(r.items));
  res.json(rows);
});
app.put("/api/admin/orders/:id",admin,(req,res)=>{
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id);
  res.json({ok:true});
});

app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.listen(PORT,()=>console.log("Big Lanche rodando na porta "+PORT));