let products=[],cart=[];
const money=n=>Number(n).toFixed(2).replace(".",",");
async function load(){products=await (await fetch("/api/products")).json();render();}
function render(){
 const groups={}; products.forEach(p=>(groups[p.category]??=[]).push(p));
 document.querySelector("#menu").innerHTML=Object.entries(groups).map(([cat,ps])=>`<section><h2>${cat}</h2><div class="grid">${ps.map(p=>`<article class="product"><div><h3>${p.name}</h3><b>R$ ${money(p.price)}</b></div><button onclick="add(${p.id})">+</button></article>`).join("")}</div></section>`).join("");
 document.querySelector("#cart").innerHTML=cart.length?cart.map((x,i)=>`<div class="cartrow"><span>${x.qty}x ${x.name}</span><span>R$ ${money(x.price*x.qty)} <button class="mini" onclick="removeItem(${i})">−</button></span></div>`).join(""):"<p>Nenhum item ainda.</p>";
 document.querySelector("#total").textContent=money(cart.reduce((s,x)=>s+x.price*x.qty,0));
}
function add(id){let p=products.find(x=>x.id===id),x=cart.find(x=>x.id===id);x?x.qty++:cart.push({...p,qty:1});render();}
function removeItem(i){cart[i].qty--;if(cart[i].qty<=0)cart.splice(i,1);render();}
document.querySelector("#orderForm").onsubmit=async e=>{e.preventDefault();if(!cart.length)return alert("Adicione algum item.");
 const f=new FormData(e.target),body={customer:f.get("customer"),phone:f.get("phone"),address:f.get("address"),items:cart,total:cart.reduce((s,x)=>s+x.price*x.qty,0)};
 const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}); const j=await r.json();
 document.querySelector("#msg").textContent=j.ok?`Pedido #${j.id} enviado!`:(j.error||"Erro"); if(j.ok){cart=[];e.target.reset();render();}
};load();